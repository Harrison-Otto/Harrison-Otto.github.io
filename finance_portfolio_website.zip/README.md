# Finance Portfolio Website

A personal portfolio website for a Finance major interested in investment banking.

## Sections
- Personal Statement
- Skills
- Projects

## Projects
1. Excel Financial Modeling Project
2. Financial Statement Analysis — Internship

## GitHub Pages
To publish:
1. Create a public GitHub repository.
2. Upload `index.html` and `style.css`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish the site.
